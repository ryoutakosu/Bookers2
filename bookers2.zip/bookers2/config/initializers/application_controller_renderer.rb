# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '6eb6fd35f63adbf0d53126c29566658654e1a5a6aa59522d2b401e94e93b0bcafd4aca131afa0e57bb4d2cfd3eba71362851b9560a886cc2915b49ecdeb9aa6e'